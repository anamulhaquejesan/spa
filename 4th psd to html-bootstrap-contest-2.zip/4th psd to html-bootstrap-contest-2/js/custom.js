// for video popup
$(Document).ready(function () {
    $('.venobox').venobox();

    // for team member slider with text
    $('.quote_text').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        speed: 1000,
        fade: true,
        asNavFor: '.quote_images'
    });
    $('.quote_images').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        asNavFor: '.quote_text',
        dots: true,
        centerMode: true,
        centerPadding: '0px',
        focusOnSelect: true,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 1000,
        speed: 1000,
    });


});